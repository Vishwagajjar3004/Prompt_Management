"""
prompt_loader.py

A small, dependency-free utility for loading .txt prompt templates,
extracting metadata (like a version number), and filling in
{{variable}} placeholders to produce a ready-to-send prompt.

Template file conventions:
    - The first few lines may contain metadata comments starting with '#',
      e.g.:
          # Version: 1.0
          # Template: email_writer
          # Description: ...
      These lines are stripped out of the final rendered prompt.
    - The rest of the file is the template body, containing
      {{variable_name}} placeholders to be filled at render time.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


PLACEHOLDER_PATTERN = re.compile(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}")
METADATA_LINE_PATTERN = re.compile(r"^#\s*([A-Za-z ]+):\s*(.*)$")


class PromptTemplateError(Exception):
    """Base error for template loading/rendering problems."""


class TemplateNotFoundError(PromptTemplateError):
    """Raised when a requested template file cannot be found."""


class MissingVariableError(PromptTemplateError):
    """Raised when required template variables are not supplied."""


@dataclass
class PromptTemplate:
    """Represents a single loaded prompt template."""

    name: str
    version: str
    metadata: dict[str, str]
    body: str
    variables: set[str] = field(default_factory=set)

    def render(self, strict: bool = True, **kwargs: Any) -> str:
        """
        Fill the template's {{variable}} placeholders with provided values.

        Args:
            strict: If True, raise MissingVariableError when required
                     variables are missing. If False, leave unfilled
                     placeholders as-is.
            **kwargs: variable_name=value pairs to substitute.

        Returns:
            The rendered prompt string.
        """
        missing = self.variables - kwargs.keys()
        if strict and missing:
            raise MissingVariableError(
                f"Template '{self.name}' is missing required variable(s): "
                f"{', '.join(sorted(missing))}"
            )

        def _substitute(match: re.Match) -> str:
            key = match.group(1)
            if key in kwargs:
                return str(kwargs[key])
            return match.group(0)  # leave placeholder untouched

        return PLACEHOLDER_PATTERN.sub(_substitute, self.body)


class PromptLoader:
    """
    Loads .txt prompt templates from a directory, parses metadata
    (including a version number), and fills variables to produce
    ready-to-use prompts.
    """

    def __init__(self, prompts_dir: str | Path = "prompts"):
        self.prompts_dir = Path(prompts_dir)
        if not self.prompts_dir.exists():
            raise TemplateNotFoundError(
                f"Prompts directory not found: {self.prompts_dir}"
            )
        self._cache: dict[str, PromptTemplate] = {}

    def _resolve_path(self, name: str) -> Path:
        filename = name if name.endswith(".txt") else f"{name}.txt"
        path = self.prompts_dir / filename
        if not path.exists():
            raise TemplateNotFoundError(f"No such template: {path}")
        return path

    def load(self, name: str, use_cache: bool = True) -> PromptTemplate:
        """Load and parse a template by name (with or without .txt)."""
        cache_key = name.replace(".txt", "")
        if use_cache and cache_key in self._cache:
            return self._cache[cache_key]

        path = self._resolve_path(name)
        raw_text = path.read_text(encoding="utf-8")

        metadata: dict[str, str] = {}
        body_lines: list[str] = []
        in_header = True

        for line in raw_text.splitlines():
            if in_header and line.strip().startswith("#"):
                match = METADATA_LINE_PATTERN.match(line.strip())
                if match:
                    key = match.group(1).strip().lower()
                    value = match.group(2).strip()
                    metadata[key] = value
                continue
            else:
                in_header = False
                body_lines.append(line)

        body = "\n".join(body_lines).strip("\n")
        version = metadata.get("version", "unknown")
        variables = set(PLACEHOLDER_PATTERN.findall(body))

        template = PromptTemplate(
            name=cache_key,
            version=version,
            metadata=metadata,
            body=body,
            variables=variables,
        )
        self._cache[cache_key] = template
        return template

    def list_templates(self) -> list[str]:
        """Return the names (without .txt) of all templates in the directory."""
        return sorted(p.stem for p in self.prompts_dir.glob("*.txt"))

    def get_prompt(self, name: str, strict: bool = True, **kwargs: Any) -> str:
        """
        Convenience method: load a template by name and render it in
        one call.

            loader.get_prompt("email_writer", recipient_name="Sam", ...)
        """
        template = self.load(name)
        return template.render(strict=strict, **kwargs)


if __name__ == "__main__":
    # Minimal smoke test
    loader = PromptLoader("prompts")
    print("Available templates:", loader.list_templates())
    tpl = loader.load("email_writer")
    print(f"Loaded '{tpl.name}' v{tpl.version}, variables: {sorted(tpl.variables)}")
