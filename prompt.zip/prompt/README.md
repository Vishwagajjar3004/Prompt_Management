# Prompt Template System

A small, dependency-free system for storing prompt templates as `.txt` files,
loading them, filling in `{{variable}}` placeholders, and (optionally) sending
the finished prompt to Claude.

## Structure

```
prompt_project/
├── prompts/
│   ├── email_writer.txt
│   ├── code_reviewer.txt
│   ├── data_summarizer.txt
│   ├── faq_answerer.txt
│   └── bug_reporter.txt
├── prompt_loader.py     # PromptLoader / PromptTemplate classes
├── demo.py              # loads all 5 templates with sample data
└── README.md
```

## Template format

Each `.txt` file starts with `#`-comment metadata lines, followed by the
template body:

```
# Version: 1.0
# Template: email_writer
# Description: Drafts a professional email...

You are an expert professional email writer.
...
Recipient: {{recipient_name}}
...
```

The metadata lines are stripped out at render time. `{{variable_name}}`
placeholders in the body get substituted when you render the template.

## PromptLoader usage

```python
from prompt_loader import PromptLoader

loader = PromptLoader("prompts")

# List available templates
loader.list_templates()
# ['bug_reporter', 'code_reviewer', 'data_summarizer', 'email_writer', 'faq_answerer']

# Load + inspect a template
tpl = loader.load("email_writer")
tpl.version      # '1.0'
tpl.variables    # {'recipient_name', 'purpose', 'tone', ...}

# Render it
prompt = tpl.render(
    recipient_name="Priya Shah",
    recipient_role="Head of Partnerships",
    sender_name="Alex Chen",
    purpose="Follow up after our demo",
    tone="warm but professional",
    key_points="- point one\n- point two",
)

# Or in one step:
prompt = loader.get_prompt("email_writer", recipient_name="Priya Shah", ...)
```

By default, `render()`/`get_prompt()` run in **strict mode** and raise
`MissingVariableError` if you forget a required variable. Pass
`strict=False` to leave unfilled placeholders as-is instead.

## Setting up API keys with .env

Instead of exporting keys in your shell every time, store them in a
`.env` file in the project root (this file is git-ignored, so it never
gets committed):

```bash
cp .env.example .env
```

Then open `.env` and paste in your real key(s):

```
ANTHROPIC_API_KEY=sk-ant-api03-...        # from console.anthropic.com/settings/keys
GEMINI_API_KEY=...                        # from aistudio.google.com/app/apikey
```

`demo.py` automatically loads `.env` on startup via `python-dotenv` —
no manual `export` needed.

## Running the demo

The demo loads all 5 templates with sample data and prints the fully
rendered prompt for each. Pass `--provider` to also call a real model:

```bash
pip install -r requirements.txt

python3 demo.py                    # render prompts only, no API calls
python3 demo.py --provider claude  # render + call Claude
python3 demo.py --provider gemini  # render + call Gemini (Google AI Studio)
python3 demo.py --provider both    # render + call both, side by side
```

If a requested provider's key isn't found in `.env` / your environment,
the demo prints a warning and skips just that provider rather than
crashing.

## Adding a new template

1. Create `prompts/your_template.txt`.
2. Add a `# Version: 1.0` metadata line at the top.
3. Write the prompt body with `{{variable}}` placeholders.
4. Load it with `loader.load("your_template")` — no code changes needed.

## Versioning templates

Each template carries its own version in its metadata header
(`# Version: 1.0`). When you materially change a template's wording or
required variables, bump this number so you can track which version
produced a given output (e.g. in logs or evals).
