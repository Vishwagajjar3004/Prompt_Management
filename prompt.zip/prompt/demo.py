"""
demo.py

Demonstrates PromptLoader by loading each of the 5 templates with
sample data, rendering the final prompt, and (if API keys are
available) sending it to Claude and/or Gemini and printing the
response.

API keys are read from a ".env" file in this directory (or from
already-exported environment variables).

Usage:
    python3 demo.py                    # render only, no keys needed
    python3 demo.py --provider claude  # render + call Claude
    python3 demo.py --provider gemini  # render + call Gemini
    python3 demo.py --provider both    # render + call both

Setup:
    pip install -r requirements.txt
    cp .env.example .env
    # then edit .env and paste in your real API key(s)
"""

import argparse
import os
import sys

from dotenv import load_dotenv

from prompt_loader import PromptLoader

load_dotenv()  # reads .env in this directory into os.environ

SAMPLE_CALLS = [
    {
        "name": "email_writer",
        "variables": {
            "recipient_name": "Priya Shah",
            "recipient_role": "Head of Partnerships",
            "sender_name": "Alex Chen",
            "purpose": "Follow up after our product demo and propose next steps",
            "tone": "warm but professional",
            "key_points": (
                "- Thanks for taking the time to see the demo yesterday\n"
                "- Recap the two features they were most excited about\n"
                "- Propose a 30-minute call next week to discuss pricing\n"
                "- Offer two specific time slots"
            ),
        },
    },
    {
        "name": "code_reviewer",
        "variables": {
            "language": "python",
            "file_context": "utils/discount.py - pricing helper used at checkout",
            "code": (
                "def apply_discount(price, pct):\n"
                "    price = price - price * pct\n"
                "    return price\n"
            ),
            "focus_areas": "correctness, edge cases, naming",
        },
    },
    {
        "name": "data_summarizer",
        "variables": {
            "dataset_description": "Weekly active users by region, last 8 weeks",
            "audience": "product leadership, non-technical",
            "data": (
                "Week,NA,EU,APAC\n"
                "1,12000,8000,4000\n"
                "2,12500,8100,4300\n"
                "3,11800,8050,4600\n"
                "4,13000,7900,5100\n"
                "5,13400,7850,5600\n"
                "6,13100,7700,6200\n"
                "7,13900,7650,6900\n"
                "8,14200,7500,7500\n"
            ),
            "num_insights": "3",
        },
    },
    {
        "name": "faq_answerer",
        "variables": {
            "company_name": "Northwind Cloud Storage",
            "knowledge_base_context": (
                "Free plan includes 5GB storage. Pro plan ($9/mo) includes 1TB "
                "storage and priority support. Storage upgrades can be purchased "
                "anytime from Account > Billing. Refunds are available within "
                "14 days of purchase."
            ),
            "question": "Can I get a refund if I upgraded to Pro yesterday but changed my mind?",
            "escalation_path": "contacting support@northwindcloud.example",
            "tone": "friendly and reassuring",
            "max_length": "80",
        },
    },
    {
        "name": "bug_reporter",
        "variables": {
            "raw_notes": (
                "user says app crashes when they tap 'export csv' on the reports "
                "page, happens every time, started after last update"
            ),
            "environment": "iOS 18.4, app v3.2.1, iPhone 14",
            "severity": "high",
        },
    },
]


def call_claude(prompt: str) -> str:
    """Call the Anthropic API with the given prompt and return the text response."""
    import anthropic

    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=500,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(
        block.text for block in response.content if getattr(block, "type", None) == "text"
    )


def call_gemini(prompt: str) -> str:
    """Call the Google AI Studio (Gemini) API with the given prompt."""
    from google import genai

    client = genai.Client()  # reads GEMINI_API_KEY (or GOOGLE_API_KEY) from env
    response = client.models.generate_content(
        model="gemini-3.5-flash",
        contents=prompt,
    )
    return response.text


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--provider",
        choices=["none", "claude", "gemini", "both"],
        default="none",
        help="Which AI provider(s) to call. Default: render prompts only.",
    )
    args = parser.parse_args()

    loader = PromptLoader("prompts")

    have_claude_key = bool(os.environ.get("ANTHROPIC_API_KEY"))
    have_gemini_key = bool(
        os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    )

    want_claude = args.provider in ("claude", "both")
    want_gemini = args.provider in ("gemini", "both")

    if want_claude and not have_claude_key:
        print("Warning: --provider claude requested but ANTHROPIC_API_KEY is not set.\n")
        want_claude = False
    if want_gemini and not have_gemini_key:
        print("Warning: --provider gemini requested but GEMINI_API_KEY is not set.\n")
        want_gemini = False

    if args.provider == "none":
        print("(Rendering prompts only. Use --provider claude / gemini / both to call an API.)\n")

    for call in SAMPLE_CALLS:
        name = call["name"]
        template = loader.load(name)
        prompt = template.render(**call["variables"])

        print("=" * 80)
        print(f"TEMPLATE: {name}  (version {template.version})")
        print("=" * 80)
        print(prompt)
        print("-" * 80)

        if want_claude:
            try:
                reply = call_claude(prompt)
                print("CLAUDE RESPONSE:\n")
                print(reply)
                print("-" * 80)
            except Exception as exc:  # noqa: BLE001
                print(f"[Claude API call failed: {exc}]")

        if want_gemini:
            try:
                reply = call_gemini(prompt)
                print("GEMINI RESPONSE:\n")
                print(reply)
                print("-" * 80)
            except Exception as exc:  # noqa: BLE001
                print(f"[Gemini API call failed: {exc}]")

        print()


if __name__ == "__main__":
    sys.exit(main())
